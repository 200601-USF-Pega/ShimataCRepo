package main.java.web;

public class DBProps {
	public static String url = "jdbc:postgresql://ruby.db.elephantsql.com:5432/ryinjoye";
	public static String username = "ryinjoye";
	public static String password = "U8mKCXXKhJ1JD4s_O1n6eqG6pJX7dtes";
}
