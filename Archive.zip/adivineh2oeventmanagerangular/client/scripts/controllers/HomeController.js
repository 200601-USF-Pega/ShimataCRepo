myApp.controller('HomeController', function() {
  var self = this;
	// self.testMessage = 'homePage';
}); // end controller code block
