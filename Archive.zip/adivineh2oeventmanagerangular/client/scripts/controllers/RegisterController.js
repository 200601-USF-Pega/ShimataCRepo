myApp.controller('RegisterController', ['$scope',
	function($scope){

		$scope.register = function() {
			//take in form data

			//validate form data is correct

			//send to route

			//.then interprit response

			//if success
			//clear form
			//link to login page and produce a message

			//else make message produce the errors
		};
		console.log('registerController yo');
	}
]);
